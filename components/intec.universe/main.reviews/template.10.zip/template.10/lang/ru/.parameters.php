<?php

$MESS['C_MAIN_STAFF_TEMPLATE_2_COLUMNS'] = 'Количество элементов в строке';
$MESS['C_MAIN_STAFF_TEMPLATE_2_HIDING_USE'] = 'Скрывать часть строк элементов';
$MESS['C_MAIN_STAFF_TEMPLATE_2_HIDING_VISIBLE'] = 'Количество видимых строк элементов';